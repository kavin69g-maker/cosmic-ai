/**
 * Firebase project configuration.
 *
 * Get these values from: Firebase Console -> Project Settings ->
 * General -> "Your apps" -> Web app -> SDK setup and configuration.
 *
 * These values are NOT secret — they identify your project publicly
 * and are safe to ship inside the app. Security comes from Firestore
 * rules + Cloud Functions auth checks, not from hiding this object.
 */
const firebaseConfig = {
  apiKey: "REPLACE_WITH_YOUR_FIREBASE_API_KEY",
  authDomain: "REPLACE_WITH_YOUR_PROJECT.firebaseapp.com",
  projectId: "REPLACE_WITH_YOUR_PROJECT_ID",
  storageBucket: "REPLACE_WITH_YOUR_PROJECT.appspot.com",
  messagingSenderId: "REPLACE_WITH_SENDER_ID",
  appId: "REPLACE_WITH_APP_ID",
};

// The base URL of your deployed Cloud Functions.
// After `firebase deploy --only functions`, the CLI prints these URLs.
// Format is usually:
// https://us-central1-YOUR_PROJECT_ID.cloudfunctions.net
const FUNCTIONS_BASE_URL = "https://us-central1-REPLACE_WITH_YOUR_PROJECT_ID.cloudfunctions.net";

// Your Google Play subscription product ID — must match Play Console exactly.
const PREMIUM_PRODUCT_ID = "cosmic_ai_premium_monthly";
