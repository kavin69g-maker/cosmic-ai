/**
 * Cosmic AI — Cloud Functions backend
 * ------------------------------------------------------------
 * This is the ONLY place your Claude API key lives. It never
 * ships inside the Android app, so it can't be extracted by
 * decompiling the APK.
 *
 * Three endpoints:
 *   chat            -> proxies a message to Claude, enforces
 *                       free-tier daily limits server-side
 *   verifyPurchase  -> verifies a real Google Play purchase
 *                       token and marks the user premium
 *   getStatus       -> returns the caller's current plan + quota
 *
 * All endpoints require a valid Firebase Auth ID token, sent as:
 *   Authorization: Bearer <idToken>
 * The frontend gets this automatically from Firebase Auth.
 */

const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const Anthropic = require("@anthropic-ai/sdk");
const { google } = require("googleapis");

admin.initializeApp();
const db = admin.firestore();

// Secrets — set these with `firebase functions:secrets:set NAME`
// Never hardcode keys in this file.
const ANTHROPIC_API_KEY = defineSecret("ANTHROPIC_API_KEY");
const PLAY_SERVICE_ACCOUNT_JSON = defineSecret("PLAY_SERVICE_ACCOUNT_JSON");

const FREE_DAILY_LIMIT = 20;
const ANDROID_PACKAGE_NAME = "com.yourcompany.cosmicai"; // CHANGE to your real package name
const PREMIUM_PRODUCT_ID = "cosmic_ai_premium_monthly";  // CHANGE to match Play Console product ID

const SYSTEM_PROMPT = `You are Cosmic AI, a science companion covering physics, chemistry, biology, quantum mechanics, space, oceans, animals, and the lives/experiments of scientists (including their failures, not just their triumphs).

Style:
- Write like a sharp, enthusiastic expert explaining things to a curious friend — clear, vivid, precise, never condescending.
- Favor concrete detail over vague abstraction: specific numbers, dates, names, mechanisms.
- When discussing scientists, treat failure as genuinely interesting, not just a prelude to success.
- Use short paragraphs. Avoid bullet-point overload.
- Never invent facts, studies, quotes, or experiments. If uncertain, say so plainly.
- Keep responses focused: usually 2-5 short paragraphs unless asked for depth.`;

/* ---------------------------------------------------------------
   Helper: verify the Firebase ID token sent from the app
--------------------------------------------------------------- */
async function requireAuth(req) {
  const authHeader = req.headers.authorization || "";
  const match = authHeader.match(/^Bearer (.+)$/);
  if (!match) {
    const err = new Error("Missing Authorization header");
    err.statusCode = 401;
    throw err;
  }
  try {
    const decoded = await admin.auth().verifyIdToken(match[1]);
    return decoded; // contains uid, email, etc.
  } catch (e) {
    const err = new Error("Invalid or expired token");
    err.statusCode = 401;
    throw err;
  }
}

/* ---------------------------------------------------------------
   Helper: get or create the user's Firestore profile
--------------------------------------------------------------- */
async function getUserDoc(uid) {
  const ref = db.collection("users").doc(uid);
  const snap = await ref.get();
  if (!snap.exists) {
    const fresh = {
      plan: "free",
      dailyCount: 0,
      lastResetDate: todayString(),
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    };
    await ref.set(fresh);
    return { ref, data: fresh };
  }
  return { ref, data: snap.data() };
}

function todayString() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD (UTC)
}

function setCors(res) {
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "Authorization, Content-Type");
  res.set("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
}

/* =================================================================
   ENDPOINT: chat
   POST { messages: [{role, content}, ...] }
   Returns: { reply: string, plan: string, remaining: number|null }
================================================================= */
exports.chat = onRequest(
  { secrets: [ANTHROPIC_API_KEY], cors: true, region: "us-central1" },
  async (req, res) => {
    setCors(res);
    if (req.method === "OPTIONS") return res.status(204).send("");
    if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });

    try {
      const user = await requireAuth(req);
      const { ref, data } = await getUserDoc(user.uid);

      // Reset daily counter if it's a new day (UTC)
      let dailyCount = data.dailyCount || 0;
      if (data.lastResetDate !== todayString()) {
        dailyCount = 0;
      }

      const plan = data.plan === "premium" ? "premium" : "free";

      if (plan === "free" && dailyCount >= FREE_DAILY_LIMIT) {
        return res.status(429).json({
          error: "DAILY_LIMIT_REACHED",
          message: `You've used all ${FREE_DAILY_LIMIT} free messages today. Upgrade for unlimited access.`,
        });
      }

      const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
      if (messages.length === 0) {
        return res.status(400).json({ error: "messages array required" });
      }
      // Basic safety: cap how much history is sent / length per message
      const trimmed = messages.slice(-20).map((m) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: String(m.content || "").slice(0, 4000),
      }));

      const anthropic = new Anthropic({ apiKey: ANTHROPIC_API_KEY.value() });
      const response = await anthropic.messages.create({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: trimmed,
      });

      const reply = (response.content || [])
        .map((b) => b.text || "")
        .join("\n")
        .trim();

      // Update usage count server-side (source of truth)
      const newCount = dailyCount + 1;
      await ref.set(
        { dailyCount: newCount, lastResetDate: todayString() },
        { merge: true }
      );

      return res.status(200).json({
        reply: reply || "I couldn't form a response to that — try rephrasing.",
        plan,
        remaining: plan === "premium" ? null : Math.max(0, FREE_DAILY_LIMIT - newCount),
      });
    } catch (e) {
      console.error("chat error:", e);
      return res.status(e.statusCode || 500).json({ error: e.message || "Internal error" });
    }
  }
);

/* =================================================================
   ENDPOINT: getStatus
   GET — returns current plan + remaining quota
================================================================= */
exports.getStatus = onRequest({ cors: true, region: "us-central1" }, async (req, res) => {
  setCors(res);
  if (req.method === "OPTIONS") return res.status(204).send("");

  try {
    const user = await requireAuth(req);
    const { data } = await getUserDoc(user.uid);

    let dailyCount = data.dailyCount || 0;
    if (data.lastResetDate !== todayString()) dailyCount = 0;

    const plan = data.plan === "premium" ? "premium" : "free";
    return res.status(200).json({
      plan,
      remaining: plan === "premium" ? null : Math.max(0, FREE_DAILY_LIMIT - dailyCount),
      dailyLimit: FREE_DAILY_LIMIT,
    });
  } catch (e) {
    console.error("getStatus error:", e);
    return res.status(e.statusCode || 500).json({ error: e.message || "Internal error" });
  }
});

/* =================================================================
   ENDPOINT: verifyPurchase
   POST { purchaseToken: string, productId: string }
   Verifies a REAL Google Play purchase server-to-server, then
   marks the user premium in Firestore. This is the only safe
   way to grant premium — never trust the client to say "I paid".
================================================================= */
exports.verifyPurchase = onRequest(
  { secrets: [PLAY_SERVICE_ACCOUNT_JSON], cors: true, region: "us-central1" },
  async (req, res) => {
    setCors(res);
    if (req.method === "OPTIONS") return res.status(204).send("");
    if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });

    try {
      const user = await requireAuth(req);
      const { purchaseToken, productId } = req.body;

      if (!purchaseToken || !productId) {
        return res.status(400).json({ error: "purchaseToken and productId required" });
      }
      if (productId !== PREMIUM_PRODUCT_ID) {
        return res.status(400).json({ error: "Unknown product ID" });
      }

      // Authenticate to Google Play Developer API using your service account
      const credentials = JSON.parse(PLAY_SERVICE_ACCOUNT_JSON.value());
      const auth = new google.auth.GoogleAuth({
        credentials,
        scopes: ["https://www.googleapis.com/auth/androidpublisher"],
      });
      const androidPublisher = google.androidpublisher({ version: "v3", auth });

      const result = await androidPublisher.purchases.subscriptions.get({
        packageName: ANDROID_PACKAGE_NAME,
        subscriptionId: productId,
        token: purchaseToken,
      });

      // paymentState: 1 = payment received, 2 = free trial, 0 = pending
      const paymentState = result.data.paymentState;
      const expiryTimeMillis = parseInt(result.data.expiryTimeMillis || "0", 10);
      const isActive = expiryTimeMillis > Date.now() && (paymentState === 1 || paymentState === 2);

      if (!isActive) {
        return res.status(400).json({ error: "Purchase not valid or not active" });
      }

      const { ref } = await getUserDoc(user.uid);
      await ref.set(
        {
          plan: "premium",
          premiumExpiry: expiryTimeMillis,
          purchaseToken,
        },
        { merge: true }
      );

      return res.status(200).json({ success: true, plan: "premium", expiryTimeMillis });
    } catch (e) {
      console.error("verifyPurchase error:", e);
      return res.status(e.statusCode || 500).json({ error: e.message || "Verification failed" });
    }
  }
);
