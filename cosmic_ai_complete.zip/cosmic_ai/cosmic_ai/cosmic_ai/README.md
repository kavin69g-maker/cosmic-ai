# Cosmic AI 🌌

**Science-Focused AI Chatbot for Android**

## Features
- Black & White Cosmic Theme
- Expert in all fields of Science (Physics, Astronomy, Biology, Chemistry, etc.)
- Chat history saved locally
- Powered by Google Gemini (free API key)
- Beautiful modern UI

## How to Build APK

1. Install Flutter: https://flutter.dev
2. Get Gemini API Key from https://aistudio.google.com/app/apikey
3. Put your API key in `lib/screens/chat_screen.dart` (line ~25)
4. Run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
5. APK will be in `build/app/outputs/flutter-apk/app-release.apk`

Made with ❤️ for science lovers.