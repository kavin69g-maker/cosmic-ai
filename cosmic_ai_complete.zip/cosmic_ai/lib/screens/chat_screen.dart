import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class ChatScreen extends StatefulWidget {
  final bool isPremium;
  const ChatScreen({super.key, this.isPremium = false});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];
  bool _isLoading = false;
  late GenerativeModel _model;
  int _messageCount = 0;
  bool _isPremium = false;

  @override
  void initState() {
    super.initState();
    _isPremium = widget.isPremium;
    _loadUserStatus();
    _loadChatHistory();
    _initGemini();
  }

  Future<void> _loadUserStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isPremium = prefs.getBool('isPremium') ?? widget.isPremium;
    });
  }

  void _initGemini() {
    // Replace with your Gemini API key (get free from Google AI Studio)
    const apiKey = 'YOUR_GEMINI_API_KEY_HERE';
    _model = GenerativeModel(
      model: 'gemini-1.5-flash',
      apiKey: apiKey,
    );
  }

  Future<void> _loadChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final history = prefs.getStringList('chat_history') ?? [];
    setState(() {
      _messages.addAll(history.map((msg) {
        final parts = msg.split(':::');
        return {'role': parts[0], 'content': parts[1]};
      }));
    });
  }

  Future<void> _saveChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final history = _messages.map((msg) => '${msg['role']}:::${msg['content']}').toList();
    await prefs.setStringList('chat_history', history);
  }

  Future<void> _sendMessage() async {
    if (_controller.text.trim().isEmpty) return;

    // Free tier limit: 10 messages per session
    if (!_isPremium && _messageCount >= 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Free limit reached. Upgrade to Premium for unlimited science chats!'),
          backgroundColor: Colors.amber,
        ),
      );
      return;
    }

    final userMessage = _controller.text.trim();
    setState(() {
      _messages.add({'role': 'user', 'content': userMessage});
      _isLoading = true;
      _messageCount++;
    });
    _controller.clear();

    await _saveChatHistory();

    try {
      final prompt = """
You are Cosmic AI, a brilliant science expert. Answer questions about physics, astronomy, biology, chemistry, earth science, technology, and all scientific topics in an engaging, accurate way.
Keep answers clear and exciting. Use simple language when possible.

User: $userMessage
""";

      final content = [Content.text(prompt)];
      final response = await _model.generateContent(content);
      final aiReply = response.text ?? "Sorry, I couldn't process that.";

      setState(() {
        _messages.add({'role': 'assistant', 'content': aiReply});
      });
    } catch (e) {
      setState(() {
        _messages.add({'role': 'assistant', 'content': "Error: $e. Make sure you added a valid Gemini API key."});
      });
    } finally {
      setState(() => _isLoading = false);
      await _saveChatHistory();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.rocket_launch, color: Colors.white),
            const SizedBox(width: 12),
            const Text('Cosmic AI', style: TextStyle(fontWeight: FontWeight.bold)),
            if (_isPremium) 
              const Padding(
                padding: EdgeInsets.only(left: 8),
                child: Chip(
                  label: Text('PREMIUM', style: TextStyle(fontSize: 12, color: Colors.black)),
                  backgroundColor: Colors.white,
                ),
              ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('chat_history');
              setState(() => _messages.clear());
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket, size: 80, color: Colors.white24),
                        SizedBox(height: 16),
                        Text(
                          'Ask me anything about Science',
                          style: TextStyle(fontSize: 20, color: Colors.white70),
                        ),
                        Text(
                          'Physics • Astronomy • Biology • Chemistry',
                          style: TextStyle(color: Colors.white38),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final msg = _messages[index];
                      final isUser = msg['role'] == 'user';
                      return Align(
                        alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: isUser ? Colors.white : Colors.grey[900],
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            msg['content']!,
                            style: TextStyle(
                              color: isUser ? Colors.black : Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          if (_isLoading)
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: CircularProgressIndicator(color: Colors.white),
            ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'Ask about the universe...',
                      hintStyle: TextStyle(color: Colors.white54),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                FloatingActionButton(
                  onPressed: _sendMessage,
                  backgroundColor: Colors.white,
                  child: const Icon(Icons.send, color: Colors.black),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
