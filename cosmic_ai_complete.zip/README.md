# Cosmic AI - Science Chatbot

A beautiful black & white Flutter Android app powered by Google's Gemini AI.

## Features
- Modern dark theme (pure black & white)
- Science-focused AI expert
- Chat history saved locally
- Clean, cosmic UI

## How to Build APK

1. Get a free Gemini API key from: https://aistudio.google.com/app/apikey
2. Replace `YOUR_GEMINI_API_KEY_HERE` in `lib/screens/chat_screen.dart`
3. Run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
4. APK will be in `build/app/outputs/flutter-apk/app-release.apk`

Enjoy exploring the universe with Cosmic AI! 🌌
